package sample;
import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Zupanija;
import covidportal.niti.DohvatiZupanijeNit;
import covidportal.niti.NajviseZarazenihNit;
import covidportal.sortiranje.CovidSorter;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class PetragaZupanijaController {
    @FXML
    private BorderPane rootPane;
    @FXML
    public TextField nazivZupanije;
    @FXML
    private TableView zupanijeTableView;
    @FXML
    private TableColumn<Zupanija, Long> tableColumnIdZupanije;
    @FXML
    private TableColumn<Zupanija, String> tableColumnNazivZupanije;
    @FXML
    private TableColumn<Zupanija, Integer> tableColumnBrojStanovnika;
    @FXML
    private TableColumn<Zupanija, Integer> tableColumnBrojZarazenih;


    ObservableList<Zupanija> listaZupanija = FXCollections.observableArrayList(DohvatiZupanijeNit.dohvatiZupanije());

    final Timeline timeline = new Timeline(
            new KeyFrame(
                    Duration.millis(10000),
                    event->{
                        Collections.sort(listaZupanija, new CovidSorter());
                        Main.getMainStage().setTitle("Najveći postotak zaraženih je u " + listaZupanija.get(0).getNaziv()); }
            )
    );

    public PetragaZupanijaController() throws BazaPodatakaException, SQLException {
    }


    @FXML
    public void initialize() throws IOException, BazaPodatakaException {
        tableColumnIdZupanije.setCellValueFactory(new PropertyValueFactory<Zupanija, Long>("id"));
        tableColumnNazivZupanije.setCellValueFactory(new PropertyValueFactory<Zupanija, String>("naziv"));
        tableColumnBrojStanovnika.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojStanovnika"));
        tableColumnBrojZarazenih.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojZarazenihOsoba"));
        for(int i =0; i<listaZupanija.size();i++) {
            System.out.println("Lista zupanija:" + listaZupanija.get(i).getNaziv().toString());
        }

        if (Optional.ofNullable(listaZupanija).isPresent()){
            ExecutorService service = Executors.newFixedThreadPool(4);
            service.execute(new NajviseZarazenihNit(listaZupanija));
        }
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
        filtrirajZupanije();
    }
    @FXML
    public void filtrirajZupanije() {
        List<Zupanija> filterZupanija;
        if (nazivZupanije.getText().isEmpty() == false) {
            filterZupanija= listaZupanija.stream()
                    .filter(p -> p.getNaziv().contains(nazivZupanije.getText())).collect(Collectors.toList());
        }
        else {
            filterZupanija = listaZupanija;
        }
        ObservableList<Zupanija> listaZupanija = FXCollections.observableArrayList(filterZupanija);
        zupanijeTableView.setItems(listaZupanija);

    }




}
