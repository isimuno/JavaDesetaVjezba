package covidportal.niti;

import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Bolest;
import covidportal.model.Osoba;
import covidportal.model.Virus;
import covidportal.model.Zupanija;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DohvatiOsobeNit implements Runnable{
    @Override
    public void run() {
        try {
            if (BazaPodataka.aktivnaVezaSBazomPodataka==true){
                wait();
            }
            else{
                notify();
                dohvatiOsobe();
            }
        } catch (BazaPodatakaException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static List<Osoba> dohvatiOsobe() throws BazaPodatakaException {
        List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();
        List<Osoba> listaOsoba = new ArrayList<>();
        List<Osoba> listaSvihOsoba = BazaPodataka.dohvatiSveOsobe();
        Bolest zarazenBolescu = new Bolest(Long.valueOf(1), "Naziv", null);
        try (Connection connection = BazaPodataka.spojiSeNaBazu()) {
            BazaPodataka.aktivnaVezaSBazomPodataka = true;
            StringBuilder sqlUpit = new StringBuilder(
                    "SELECT distinct ID, IME, PREZIME, DATUM_RODJENJA, ZUPANIJA_ID, BOLEST_ID from OSOBA");
            Statement query = connection.createStatement();
            ResultSet resultSet = query.executeQuery(sqlUpit.toString());
            while (resultSet.next()) {
                listaKontaktiranihOsoba.clear();
                zarazenBolescu = new Bolest(Long.valueOf(1), "Naziv", null);
                Long idOsobe = resultSet.getLong("ID");
                String ime = resultSet.getString("IME");
                String prezime = resultSet.getString("PREZIME");
                String datumRodenjaString = resultSet.getString("DATUM_RODJENJA");
                Long idZupanije = resultSet.getLong("ZUPANIJA_ID");
                Long idBolesti = resultSet.getLong("BOLEST_ID");
                DateTimeFormatter DATEFORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate datumRodenja = LocalDate.parse(datumRodenjaString, DATEFORMATTER);
                List<Zupanija> listaZupanija = BazaPodataka.dohvatiZupanije();
                List<Bolest> listaBolesti = BazaPodataka.dohvatiBolesti();
                List<Virus> listaVirusa = BazaPodataka.dohvatiViruse();
                Zupanija zupanijaPrebivalista = null;

                for (Zupanija z : listaZupanija) {
                    if (z.getId().equals(idZupanije)) {
                        zupanijaPrebivalista = z;
                    }
                }
                for (Bolest b : listaBolesti) {
                    System.out.println("Usporedujem : " + b.getId() + "  i  " + idBolesti);
                    if (b.getId().toString().equals(idBolesti.toString())) {
                        zarazenBolescu = b;
                    }
                }
                if (zarazenBolescu.getNaziv().equals("Naziv")) {
                    for (Virus v : listaVirusa) {
                        System.out.println("Usporedujem : " + v.getId() + "  i  " + idBolesti);
                        if (v.getId().toString().equals(idBolesti.toString())) {
                            zarazenBolescu = v;
                        }
                    }
                }

                StringBuilder sqlUpitKontaktOsobe = new StringBuilder(
                        "SELECT distinct KONTAKTIRANA_OSOBA_ID FROM KONTAKTIRANE_OSOBE WHERE OSOBA_ID =" + idOsobe);

                Statement queryKontaktOsobe = connection.createStatement();
                ResultSet resultSetKontaktOsobe = queryKontaktOsobe.executeQuery(sqlUpitKontaktOsobe.toString());
                while (resultSetKontaktOsobe.next()) {
                    Long idKontaktiraneOsobe = resultSetKontaktOsobe.getLong("KONTAKTIRANA_OSOBA_ID");
                    for (Osoba o : listaSvihOsoba) {
                        if (o.getId().toString().equals(idKontaktiraneOsobe.toString())) {
                            System.out.println("Spremam osobu : " + o.getIme());
                            listaKontaktiranihOsoba.add(o);
                        }
                    }
                }
                Set<Osoba> setKontaktiranihOsoba = new HashSet<>(listaKontaktiranihOsoba);
                List<Osoba> listaKOsoba = new ArrayList<>(setKontaktiranihOsoba);
                listaKontaktiranihOsoba.clear();
                if(listaKOsoba.isEmpty()){
                    Osoba novaOsoba = new Osoba.Builder()
                            .imaId(idOsobe)
                            .seZove(ime)
                            .sePreziva(prezime)
                            .imaGodina(datumRodenja)
                            .pripadaZupaniji(zupanijaPrebivalista)
                            .imaBolest(zarazenBolescu)
                            .build();
                    listaOsoba.add(novaOsoba);
                    BazaPodataka.aktivnaVezaSBazomPodataka = false;
                }
                else {
                    Osoba novaOsoba = new Osoba.Builder()
                            .imaId(idOsobe)
                            .seZove(ime)
                            .sePreziva(prezime)
                            .imaGodina(datumRodenja)
                            .pripadaZupaniji(zupanijaPrebivalista)
                            .imaBolest(zarazenBolescu)
                            .kontaktiraneOsobe(listaKOsoba)
                            .build();
                    listaOsoba.add(novaOsoba);
                    BazaPodataka.aktivnaVezaSBazomPodataka = false;
                }

            }
        } catch (SQLException | IOException e) {
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
            String poruka = "Došlo je do pogreške u radu s bazom podataka";
            throw new BazaPodatakaException(poruka, e);
        }
        return listaOsoba;
    }
}
