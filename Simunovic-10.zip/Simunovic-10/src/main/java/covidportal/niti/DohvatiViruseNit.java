package covidportal.niti;

import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Bolest;
import covidportal.model.Simptom;
import covidportal.model.Virus;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DohvatiViruseNit implements Runnable{
    @Override
    public void run() {
        try {
            if (BazaPodataka.aktivnaVezaSBazomPodataka==true){
                wait();
            }
            else{
                notify();
                dohvatiViruse();
            }
        } catch (BazaPodatakaException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static List<Virus> dohvatiViruse() throws BazaPodatakaException {
        List<Virus> listaVirusa = new ArrayList<>();
        List<Simptom> listaSimptomaVirusa = new ArrayList<>();
        try (Connection connection = BazaPodataka.spojiSeNaBazu()) {
            BazaPodataka.aktivnaVezaSBazomPodataka = true;
            StringBuilder sqlUpit = new StringBuilder(
                    "SELECT distinct ID, NAZIV, VIRUS from BOLEST WHERE VIRUS = TRUE");
            Statement query = connection.createStatement();
            ResultSet resultSet = query.executeQuery(sqlUpit.toString());
            while (resultSet.next()) {
                Long id = resultSet.getLong("ID");
                String naziv = resultSet.getString("NAZIV");
                StringBuilder sqlUpitSimptomiVirusa = new StringBuilder(
                        "SELECT SIMPTOM_ID FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + id);

                System.out.println("Dohvaćam za " + id);
                Statement querySimptomiVirusa = connection.createStatement();
                ResultSet resultSetSimptomiVirusa = querySimptomiVirusa.executeQuery(sqlUpitSimptomiVirusa.toString());
                List<Simptom> listaSimpoma = BazaPodataka.dohvatiSimptome();
                System.out.println("Veličina: " + listaSimptomaVirusa.size());
                listaSimptomaVirusa.clear();
                System.out.println("Veličina: " + listaSimptomaVirusa.size());
                while (resultSetSimptomiVirusa.next()) {
                    Long simptomVirusa = resultSetSimptomiVirusa.getLong("SIMPTOM_ID");
                    System.out.println("Dohvaćam simptom  " + simptomVirusa);
                    for (Simptom s : listaSimpoma) {
                        if (s.getId().toString().equals(simptomVirusa.toString())) {
                            listaSimptomaVirusa.add(s);
                        }
                    }
                }
                System.out.println(listaSimptomaVirusa);
                Set<Simptom> setSimptoma = new HashSet<>(listaSimptomaVirusa);
                Bolest newVirus = new Virus(id, naziv, setSimptoma);
                listaVirusa.add((Virus) newVirus);
                BazaPodataka.aktivnaVezaSBazomPodataka = false;
            }
        } catch (SQLException | IOException e) {
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
            String poruka = "Došlo je do pogreške u radu s bazom podataka";
            throw new BazaPodatakaException(poruka, e);
        }
        return listaVirusa;
    }
}
