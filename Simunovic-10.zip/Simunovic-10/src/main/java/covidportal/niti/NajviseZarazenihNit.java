package covidportal.niti;

import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Zupanija;
import covidportal.sortiranje.CovidSorter;
import javafx.collections.ObservableList;
import java.util.Collections;

public class NajviseZarazenihNit implements Runnable {
    ObservableList<Zupanija> listaZupanija;

    public NajviseZarazenihNit(ObservableList<Zupanija> listaZupanija) throws BazaPodatakaException {
        this.listaZupanija = listaZupanija;
    }

    @Override
    public void run() {
        while (true) {
            Collections.sort(listaZupanija, new CovidSorter());
            System.out.println("Najveći postotak zaraženih je u : " + listaZupanija.get(0).getNaziv());
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
