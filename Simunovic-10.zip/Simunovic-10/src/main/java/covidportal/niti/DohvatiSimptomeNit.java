package covidportal.niti;

import covidportal.enumeracija.VrijednostiSimptoma;
import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Simptom;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DohvatiSimptomeNit implements Runnable {
    @Override
    public void run() {
        try {
            if (BazaPodataka.aktivnaVezaSBazomPodataka==true){
                wait();
            }
            else{
                notify();
               dohvatiSimptome();
            }
        } catch (BazaPodatakaException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static List<Simptom> dohvatiSimptome() throws BazaPodatakaException {
        List<Simptom> listaSimptoma = new ArrayList<>();
        try (Connection connection = BazaPodataka.spojiSeNaBazu()) {
            BazaPodataka.aktivnaVezaSBazomPodataka = true;
            StringBuilder sqlUpit = new StringBuilder(
                    "SELECT distinct ID, NAZIV, VRIJEDNOST from SIMPTOM");
            Statement query = connection.createStatement();
            ResultSet resultSet = query.executeQuery(sqlUpit.toString());
            while (resultSet.next()) {
                Long id = resultSet.getLong("ID");
                String naziv = resultSet.getString("NAZIV");
                VrijednostiSimptoma vrijednostiSimptoma = VrijednostiSimptoma.valueOf(resultSet.getString("VRIJEDNOST"));

                Simptom newSimptom = new Simptom(id, naziv, vrijednostiSimptoma);
                listaSimptoma.add(newSimptom);
                BazaPodataka.aktivnaVezaSBazomPodataka = false;
            }
        } catch (SQLException | IOException e) {
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
            String poruka = "Došlo je do pogreške u radu s bazom podataka";
            throw new BazaPodatakaException(poruka, e);
        }
        return listaSimptoma;
    }
}
