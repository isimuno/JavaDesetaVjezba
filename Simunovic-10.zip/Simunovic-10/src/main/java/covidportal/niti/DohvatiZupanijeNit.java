package covidportal.niti;

import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Zupanija;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DohvatiZupanijeNit implements Runnable {

    @Override
    public void run() {
        try {
            if (BazaPodataka.aktivnaVezaSBazomPodataka==true){
                wait();
            }
            else{
                notify();
                dohvatiZupanije();
            }
        } catch (BazaPodatakaException | SQLException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static synchronized List<Zupanija> dohvatiZupanije() throws BazaPodatakaException, SQLException {
        List<Zupanija> listaZupanija = new ArrayList<>();
        try (Connection connection = BazaPodataka.spojiSeNaBazu()) {
            BazaPodataka.aktivnaVezaSBazomPodataka = true;
            StringBuilder sqlUpit = new StringBuilder(
                    "SELECT distinct ID, NAZIV, BROJ_STANOVNIKA, BROJ_ZARAZENIH_STANOVNIKA from ZUPANIJA ");
            Statement query = connection.createStatement();
            ResultSet resultSet = query.executeQuery(sqlUpit.toString());
            while (resultSet.next()) {
                Long id = resultSet.getLong("ZUPANIJA.ID");
                String naziv = resultSet.getString("NAZIV");
                Integer brojStanovnika = resultSet.getInt("BROJ_STANOVNIKA");
                Integer brojZarazenihStanovnika = resultSet.getInt("BROJ_ZARAZENIH_STANOVNIKA");

                Zupanija newZupanija = new Zupanija(id, naziv, brojStanovnika, brojZarazenihStanovnika);
                listaZupanija.add(newZupanija);
            }
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
        } catch (SQLException | IOException ex) {
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
            String poruka = "Došlo je do pogreške u radu s bazom podataka";
            throw new BazaPodatakaException(poruka, ex);
        }
        return listaZupanija;
    }
}
