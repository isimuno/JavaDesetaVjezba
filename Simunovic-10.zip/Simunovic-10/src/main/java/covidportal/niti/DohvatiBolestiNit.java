package covidportal.niti;

import covidportal.iznimke.BazaPodatakaException;
import covidportal.main.BazaPodataka;
import covidportal.model.Bolest;
import covidportal.model.Simptom;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DohvatiBolestiNit implements Runnable{
    @Override
    public void run() {
        try {
            if (BazaPodataka.aktivnaVezaSBazomPodataka==true){
                wait();
            }
            else{
                notify();
                dohvatiBolesti();
            }
        } catch (BazaPodatakaException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static List<Bolest> dohvatiBolesti() throws BazaPodatakaException {
        List<Bolest> listaBolesti = new ArrayList<>();
        List<Simptom> listaSimptomaBolesti = new ArrayList<>();
        try (Connection connection = BazaPodataka.spojiSeNaBazu()) {
            BazaPodataka.aktivnaVezaSBazomPodataka = true;
            StringBuilder sqlUpit = new StringBuilder(
                    "SELECT distinct ID, NAZIV, VIRUS from BOLEST WHERE VIRUS = FALSE");
            Statement query = connection.createStatement();
            ResultSet resultSet = query.executeQuery(sqlUpit.toString());
            while (resultSet.next()) {
                Long id = resultSet.getLong("ID");
                String naziv = resultSet.getString("NAZIV");
                StringBuilder sqlUpitSimptomiBolesti = new StringBuilder(
                        "SELECT SIMPTOM_ID FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + id);

                System.out.println("Dohvaćam za " + id);
                Statement querySimptomiBolesti = connection.createStatement();
                ResultSet resultSetSimptomiBolesti = querySimptomiBolesti.executeQuery(sqlUpitSimptomiBolesti.toString());
                List<Simptom> listaSimpoma = BazaPodataka.dohvatiSimptome();
                listaSimptomaBolesti.clear();
                while (resultSetSimptomiBolesti.next()) {
                    Long simptomBolesti = resultSetSimptomiBolesti.getLong("SIMPTOM_ID");
                    System.out.println("Dohvaćam simptom  " + simptomBolesti);
                    for (Simptom s : listaSimpoma) {
                        if (s.getId().toString().equals(simptomBolesti.toString())) {
                            listaSimptomaBolesti.add(s);
                        }
                    }
                }
                System.out.println(listaSimptomaBolesti);
                Set<Simptom> setSimptoma = new HashSet<>(listaSimptomaBolesti);
                Bolest newBolest = new Bolest(id, naziv, setSimptoma);
                listaBolesti.add(newBolest);
                BazaPodataka.aktivnaVezaSBazomPodataka = false;
            }
        } catch (SQLException | IOException e) {
            BazaPodataka.aktivnaVezaSBazomPodataka = false;
            String poruka = "Došlo je do pogreške u radu s bazom podataka";
            throw new BazaPodatakaException(poruka, e);
        }
        return listaBolesti;
    }
}
